<?php
/**
 * Copyright © Shipment All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Vdcstore\Shipment\Observer\Sales;

use Magento\Framework\Event\ObserverInterface;


class OrderShipmentSaveBefore implements \Magento\Framework\Event\ObserverInterface
{

    protected $stockState;
    protected $sourceItemsSaveInterface;
    protected $sourceItemFactory;
    public $request;

    /**
     * Execute observer
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */

    public function __construct(
        \Magento\CatalogInventory\Api\StockStateInterface $stockState,
        \Magento\InventoryApi\Api\SourceItemsSaveInterface $sourceItemsSaveInterface,
        \Magento\InventoryApi\Api\Data\SourceItemInterfaceFactory $sourceItemFactory,
        \Magento\Framework\App\RequestInterface $request
    )
    {
        $this->stockState = $stockState;
        $this->sourceItemsSaveInterface = $sourceItemsSaveInterface;
        $this->sourceItemFactory = $sourceItemFactory;
        $this->request = $request;

    }

    public function execute(
        \Magento\Framework\Event\Observer $observer,
    ) {

        $post = $this->request->getPost();
        $sourceCode = $this->request->getParam('sourceCode');
        $items = $observer->getEvent()->getShipment()->getAllItems();
        if ($items) {
            foreach ($items as $item) {
                $productId = $item->getProductId();
                $qty = $this->stockState->getStockQty($productId);
                $itemQty = $item->getQty();
                if ($qty < $itemQty) {
                    $sourceItem = $this->sourceItemFactory->create();
                    $sourceItem->setSourceCode($sourceCode);
                    $sourceItem->setSku($item->getSku());
                    $sourceItem->setQuantity($itemQty);
                    $sourceItem->setStatus(1);
                    $this->sourceItemsSaveInterface->execute([$sourceItem]);
                }
            }
        }
    }
}
