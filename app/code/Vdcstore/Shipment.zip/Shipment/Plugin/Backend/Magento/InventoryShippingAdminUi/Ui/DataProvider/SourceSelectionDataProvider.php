<?php
/**
 * Copyright © Shipment All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Vdcstore\Shipment\Plugin\Backend\Magento\InventoryShippingAdminUi\Ui\DataProvider;

class SourceSelectionDataProvider
{

    public function afterGetData(
        \Magento\InventoryShippingAdminUi\Ui\DataProvider\SourceSelectionDataProvider $subject,
        $result
    )
    {
        foreach ($result as $key => &$value) {
            $items = &$value['items'];
            foreach ($items as $itemKey => &$itemValue) {
                $qtyToShip = $itemValue['qtyToShip'];
                $sources = &$itemValue['sources'];
                foreach ($sources as $sourcesKey => &$sourcesValue) {
                    if ($sourcesValue['qtyAvailable'] <= 0) {
                        $sourcesValue['qtyAvailable'] = $qtyToShip;
                        $sourcesValue['qtyToDeduct'] = $qtyToShip;
                    }
                }
            }
        }
        return $result;
    }
}
