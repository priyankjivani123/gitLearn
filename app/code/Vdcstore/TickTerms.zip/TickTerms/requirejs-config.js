var config = {
    map: {
        '*': {
            'Magento_Checkout/template/minicart/item/default': 'Vdcstore_TickTerms/template/minicart/item/default',
            'Magento_Checkout/template/summary/item/details': 'Vdcstore_TickTerms/template/summary/item/details'
        }
    }
};
