var config = {
    map: {
        '*': {
            'Magento_Checkout/template/minicart/item/default.html': 'Vdcstore_TickTerms/template/minicart/item/default.html',
            'Magento_Checkout/template/summary/item/details.html': 'Vdcstore_TickTerms/template/summary/item/details.html'
        }
    }
};